export interface Photo {
    id: number;
    url: string;
    ismain: boolean;
}